# Hackathon Platform

This project is a management platform for running hackathons and competitions. It provides a Spring Boot REST API backend to manage participants, teams, tracks, submissions, and judge scoring, along with an interactive Python CLI client for testing the flows.

## Project Overview

The backend handles the core data validation and logic for the event lifecycle. This includes registering participants (preventing email duplication), organizing teams with max-size enforcement, assigning judges to evaluation tracks, and registering multi-criteria scores to generate a real-time leaderboard.

## Tech Stack

- Java 21 & Spring Boot 3
- MongoDB (Database)
- Python 3 (CLI Client)
- Swagger UI (API Docs and testing)

## Setup & Running

1. **MongoDB**: Make sure MongoDB is running locally on port `27017`. The app uses the database configuration specified in `src/main/resources/application.properties`.
2. **Backend Server**: Run the following command from the project root to start the backend:
   ```powershell
   .\mvnw.cmd spring-boot:run
   ```
   *(Use `./mvnw spring-boot:run` on Mac/Linux)*. The server boots on port `8080`.
3. **CLI Client**: Install the requests dependency and start the CUI:
   ```bash
   pip install requests
   python hackathon_cli.py
   ```

## Core Endpoints / Routes

| Method | Path | Description |
|---|---|---|
| `POST` | `/hackathons` | Create a new hackathon event (defaults to Draft) |
| `PATCH` | `/hackathons/{id}/status` | Transition status (Draft, Registration, Active, Judging, Closed) |
| `POST` | `/participants` | Register a new participant (validates email is unique) |
| `POST` | `/teams` | Form a team (generates an 8-character unique join code) |
| `POST` | `/teams/{code}/join` | Add participant to team (validates hackathon max team size) |
| `POST` | `/judges` | Register a judge |
| `POST` | `/judges/{id}/assign` | Assign a judge to a track (e.g. AI, Web development) |
| `POST` | `/scores` | Submit innovation, execution, and presentation scores (verifies judge's track) |
| `POST` | `/submissions` | Submit project repository and demo links under a track |

## Data Flow Verification

All endpoints and data flows were verified end-to-end using Swagger UI (accessible at `http://localhost:8080/swagger-ui.html`) and by running the Python terminal client to ensure database state changes persist correctly in MongoDB.

