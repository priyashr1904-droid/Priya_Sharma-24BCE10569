#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║           HACKATHON PLATFORM — Command Line Interface        ║
║       Interactive terminal client for the REST API           ║
╚══════════════════════════════════════════════════════════════╝

Requires: Python 3.8+, 'requests' library
Install:  pip install requests
Usage:    python hackathon_cli.py
          python hackathon_cli.py --base-url http://localhost:9090
"""

import sys
import json
import argparse
import requests
from datetime import date

# ──────────────────────────────────────────────────────────────
# ANSI colour codes for terminal styling
# ──────────────────────────────────────────────────────────────
class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    UNDER   = "\033[4m"

    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"

    BG_BLUE = "\033[44m"
    BG_MAG  = "\033[45m"
    BG_CYAN = "\033[46m"


# ──────────────────────────────────────────────────────────────
# Utility helpers
# ──────────────────────────────────────────────────────────────
BASE_URL = "http://localhost:8080"


def hr(char="─", width=62):
    print(f"{C.DIM}{char * width}{C.RESET}")


def banner():
    print()
    print(f"{C.BOLD}{C.CYAN}╔══════════════════════════════════════════════════════════════╗{C.RESET}")
    print(f"{C.BOLD}{C.CYAN}║{C.RESET}  {C.BOLD}{C.MAGENTA}⚡  HACKATHON PLATFORM  ⚡{C.RESET}           {C.DIM}Command-Line Interface{C.RESET}  {C.BOLD}{C.CYAN}║{C.RESET}")
    print(f"{C.BOLD}{C.CYAN}╚══════════════════════════════════════════════════════════════╝{C.RESET}")
    print(f"  {C.DIM}Server: {BASE_URL}{C.RESET}")
    print()


def success(msg):
    print(f"\n  {C.GREEN}✔  {msg}{C.RESET}")


def error(msg):
    print(f"\n  {C.RED}✖  {msg}{C.RESET}")


def warn(msg):
    print(f"\n  {C.YELLOW}⚠  {msg}{C.RESET}")


def info(msg):
    print(f"  {C.CYAN}ℹ  {msg}{C.RESET}")


def prompt(label, default=None, required=True):
    """Prompt for user input with optional default."""
    suffix = f" {C.DIM}[{default}]{C.RESET}" if default else ""
    req_marker = f"{C.RED}*{C.RESET}" if required else ""
    val = input(f"  {req_marker}{C.YELLOW}{label}{C.RESET}{suffix}: ").strip()
    if not val and default is not None:
        return default
    if not val and required:
        error(f"{label} is required.")
        return prompt(label, default, required)
    return val


def prompt_int(label, default=None, required=True, lo=None, hi=None):
    """Prompt for an integer."""
    while True:
        val = prompt(label, default=str(default) if default is not None else None, required=required)
        if not val and not required:
            return None
        try:
            n = int(val)
            if lo is not None and n < lo:
                error(f"Value must be ≥ {lo}.")
                continue
            if hi is not None and n > hi:
                error(f"Value must be ≤ {hi}.")
                continue
            return n
        except ValueError:
            error("Please enter a valid integer.")


def prompt_optional(label):
    return prompt(label, required=False) or None


def api(method, path, json_body=None):
    """Make an HTTP request and return (success, data_or_message)."""
    url = f"{BASE_URL}{path}"
    try:
        resp = getattr(requests, method)(url, json=json_body, timeout=10)
        if resp.status_code == 204:
            return True, None
        if resp.status_code in (200, 201):
            return True, resp.json()
        # Try to pull a useful error message
        try:
            body = resp.json()
            msg = body.get("message") or body.get("error") or json.dumps(body, indent=2)
        except Exception:
            msg = resp.text or f"HTTP {resp.status_code}"
        return False, msg
    except requests.ConnectionError:
        return False, f"Cannot connect to {BASE_URL}. Is the server running?"
    except requests.Timeout:
        return False, "Request timed out."
    except Exception as e:
        return False, str(e)


def print_table(headers, rows, col_widths=None):
    """Pretty-print an ASCII table."""
    if not rows:
        info("No records found.")
        return

    if col_widths is None:
        col_widths = []
        for i, h in enumerate(headers):
            max_w = len(h)
            for r in rows:
                cell = str(r[i]) if i < len(r) else ""
                max_w = max(max_w, len(cell))
            col_widths.append(min(max_w + 2, 40))

    def fmt_row(cells, color=""):
        parts = []
        for i, cell in enumerate(cells):
            w = col_widths[i] if i < len(col_widths) else 20
            parts.append(str(cell).ljust(w)[:w])
        return f"  {color}│ {'│ '.join(parts)}│{C.RESET}"

    sep = f"  {C.DIM}├{'┼'.join('─' * w for w in col_widths)}┤{C.RESET}"
    top = f"  {C.DIM}┌{'┬'.join('─' * w for w in col_widths)}┐{C.RESET}"
    bot = f"  {C.DIM}└{'┴'.join('─' * w for w in col_widths)}┘{C.RESET}"

    print(top)
    print(fmt_row(headers, C.BOLD + C.CYAN))
    print(sep)
    for row in rows:
        print(fmt_row(row))
    print(bot)
    print(f"  {C.DIM}{len(rows)} record(s){C.RESET}")


def show_entity(label, obj, fields):
    """Display a single entity in card format."""
    print()
    print(f"  {C.BOLD}{C.MAGENTA}┌─ {label} ─────────────────────────────────────┐{C.RESET}")
    for key, display in fields:
        val = obj.get(key, "—")
        if isinstance(val, list):
            val = ", ".join(val) if val else "—"
        print(f"  {C.MAGENTA}│{C.RESET}  {C.BOLD}{display:18s}{C.RESET} {val}")
    print(f"  {C.MAGENTA}└───────────────────────────────────────────────┘{C.RESET}")


def menu_choice(title, options):
    """Display a numbered menu and return the user's choice (1-indexed)."""
    print()
    print(f"  {C.BOLD}{C.BG_CYAN}{C.WHITE} {title} {C.RESET}")
    hr()
    for i, (label, _) in enumerate(options, 1):
        color = C.YELLOW if label.startswith("←") else C.WHITE
        print(f"  {C.BOLD}{C.CYAN}[{i}]{C.RESET} {color}{label}{C.RESET}")
    hr()
    while True:
        try:
            ch = input(f"  {C.GREEN}▸ Choose [1-{len(options)}]: {C.RESET}").strip()
            n = int(ch)
            if 1 <= n <= len(options):
                return n
        except (ValueError, EOFError):
            pass
        error(f"Please enter a number between 1 and {len(options)}.")


def pause():
    input(f"\n  {C.DIM}Press Enter to continue...{C.RESET}")


# ══════════════════════════════════════════════════════════════
#  HACKATHON MANAGEMENT
# ══════════════════════════════════════════════════════════════
def hackathon_menu():
    while True:
        choice = menu_choice("HACKATHON MANAGEMENT", [
            ("Create Hackathon",       None),
            ("List All Hackathons",    None),
            ("View Hackathon by ID",   None),
            ("Update Hackathon",       None),
            ("Change Status",          None),
            ("Delete Hackathon",       None),
            ("← Back to Main Menu",    None),
        ])
        if   choice == 1: create_hackathon()
        elif choice == 2: list_hackathons()
        elif choice == 3: view_hackathon()
        elif choice == 4: update_hackathon()
        elif choice == 5: change_hackathon_status()
        elif choice == 6: delete_hackathon()
        elif choice == 7: return


def create_hackathon():
    print(f"\n  {C.BOLD}{C.MAGENTA}── Create New Hackathon ──{C.RESET}")
    body = {
        "title":      prompt("Title"),
        "theme":      prompt_optional("Theme"),
        "startDate":  prompt_optional("Start Date (YYYY-MM-DD)"),
        "endDate":    prompt_optional("End Date (YYYY-MM-DD)"),
        "maxTeamSize": prompt_int("Max Team Size", default=5, required=False),
    }
    body = {k: v for k, v in body.items() if v is not None}
    ok, data = api("post", "/hackathons", body)
    if ok:
        success(f"Hackathon created!  ID: {C.BOLD}{data['id']}{C.RESET}")
        show_entity("Hackathon", data, [
            ("id", "ID"), ("title", "Title"), ("theme", "Theme"),
            ("startDate", "Start Date"), ("endDate", "End Date"),
            ("status", "Status"), ("maxTeamSize", "Max Team Size"),
        ])
    else:
        error(data)
    pause()


def list_hackathons():
    ok, data = api("get", "/hackathons")
    if ok:
        rows = [(h.get("id",""), h.get("title",""), h.get("theme","—"),
                 h.get("status",""), h.get("startDate","—"), h.get("endDate","—"))
                for h in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── All Hackathons ──{C.RESET}")
        print_table(["ID", "Title", "Theme", "Status", "Start", "End"], rows)
    else:
        error(data)
    pause()


def view_hackathon():
    hid = prompt("Hackathon ID")
    ok, data = api("get", f"/hackathons/{hid}")
    if ok:
        show_entity("Hackathon", data, [
            ("id", "ID"), ("title", "Title"), ("theme", "Theme"),
            ("startDate", "Start Date"), ("endDate", "End Date"),
            ("status", "Status"), ("maxTeamSize", "Max Team Size"),
        ])
    else:
        error(data)
    pause()


def update_hackathon():
    hid = prompt("Hackathon ID to update")
    print(f"  {C.DIM}(Leave blank to skip a field){C.RESET}")
    body = {}
    v = prompt_optional("New Title")
    if v: body["title"] = v
    v = prompt_optional("New Theme")
    if v: body["theme"] = v
    v = prompt_optional("New Start Date (YYYY-MM-DD)")
    if v: body["startDate"] = v
    v = prompt_optional("New End Date (YYYY-MM-DD)")
    if v: body["endDate"] = v
    v = prompt_optional("New Max Team Size")
    if v:
        try: body["maxTeamSize"] = int(v)
        except: pass
    if not body:
        warn("Nothing to update.")
        return
    ok, data = api("patch", f"/hackathons/{hid}", body)
    if ok:
        success("Hackathon updated!")
        show_entity("Hackathon", data, [
            ("id", "ID"), ("title", "Title"), ("theme", "Theme"),
            ("startDate", "Start Date"), ("endDate", "End Date"),
            ("status", "Status"), ("maxTeamSize", "Max Team Size"),
        ])
    else:
        error(data)
    pause()


def change_hackathon_status():
    hid = prompt("Hackathon ID")
    print(f"  {C.DIM}Lifecycle: Draft → Registration → Active → Judging → Closed{C.RESET}")
    new_status = prompt("New Status")
    ok, data = api("patch", f"/hackathons/{hid}/status", {"status": new_status})
    if ok:
        success(f"Status changed to: {C.BOLD}{data.get('status')}{C.RESET}")
    else:
        error(data)
    pause()


def delete_hackathon():
    hid = prompt("Hackathon ID to delete")
    confirm = input(f"  {C.RED}⚠ Are you sure? (yes/no): {C.RESET}").strip().lower()
    if confirm in ("yes", "y"):
        ok, data = api("delete", f"/hackathons/{hid}")
        if ok:
            success("Hackathon deleted.")
        else:
            error(data)
    else:
        info("Cancelled.")
    pause()


# ══════════════════════════════════════════════════════════════
#  PARTICIPANT MANAGEMENT
# ══════════════════════════════════════════════════════════════
def participant_menu():
    while True:
        choice = menu_choice("PARTICIPANT MANAGEMENT", [
            ("Register Participant",    None),
            ("List All Participants",   None),
            ("View Participant by ID",  None),
            ("Update Participant",      None),
            ("Delete Participant",      None),
            ("← Back to Main Menu",     None),
        ])
        if   choice == 1: create_participant()
        elif choice == 2: list_participants()
        elif choice == 3: view_participant()
        elif choice == 4: update_participant()
        elif choice == 5: delete_participant()
        elif choice == 6: return


def create_participant():
    print(f"\n  {C.BOLD}{C.MAGENTA}── Register Participant ──{C.RESET}")
    body = {
        "name":           prompt("Name"),
        "email":          prompt("Email"),
        "skills":         prompt_optional("Skills"),
        "githubProfile":  prompt_optional("GitHub Profile URL"),
        "teamId":         prompt_optional("Team ID (if already assigned)"),
    }
    body = {k: v for k, v in body.items() if v is not None}
    ok, data = api("post", "/participants", body)
    if ok:
        success(f"Participant registered!  ID: {C.BOLD}{data['id']}{C.RESET}")
        show_entity("Participant", data, [
            ("id", "ID"), ("name", "Name"), ("email", "Email"),
            ("skills", "Skills"), ("githubProfile", "GitHub"),
            ("registrationDate", "Registered"), ("teamId", "Team ID"),
        ])
    else:
        error(data)
    pause()


def list_participants():
    ok, data = api("get", "/participants")
    if ok:
        rows = [(p.get("id",""), p.get("name",""), p.get("email",""),
                 p.get("skills","—"), p.get("teamId","—"))
                for p in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── All Participants ──{C.RESET}")
        print_table(["ID", "Name", "Email", "Skills", "Team ID"], rows)
    else:
        error(data)
    pause()


def view_participant():
    pid = prompt("Participant ID")
    ok, data = api("get", f"/participants/{pid}")
    if ok:
        show_entity("Participant", data, [
            ("id", "ID"), ("name", "Name"), ("email", "Email"),
            ("skills", "Skills"), ("githubProfile", "GitHub"),
            ("registrationDate", "Registered"), ("teamId", "Team ID"),
        ])
    else:
        error(data)
    pause()


def update_participant():
    pid = prompt("Participant ID to update")
    print(f"  {C.DIM}(Leave blank to skip a field){C.RESET}")
    body = {}
    v = prompt_optional("New Name")
    if v: body["name"] = v
    v = prompt_optional("New Skills")
    if v: body["skills"] = v
    v = prompt_optional("New GitHub Profile URL")
    if v: body["githubProfile"] = v
    if not body:
        warn("Nothing to update.")
        return
    ok, data = api("patch", f"/participants/{pid}", body)
    if ok:
        success("Participant updated!")
        show_entity("Participant", data, [
            ("id", "ID"), ("name", "Name"), ("email", "Email"),
            ("skills", "Skills"), ("githubProfile", "GitHub"),
        ])
    else:
        error(data)
    pause()


def delete_participant():
    pid = prompt("Participant ID to delete")
    confirm = input(f"  {C.RED}⚠ Are you sure? (yes/no): {C.RESET}").strip().lower()
    if confirm in ("yes", "y"):
        ok, data = api("delete", f"/participants/{pid}")
        if ok:
            success("Participant removed.")
        else:
            error(data)
    else:
        info("Cancelled.")
    pause()


# ══════════════════════════════════════════════════════════════
#  TEAM MANAGEMENT
# ══════════════════════════════════════════════════════════════
def team_menu():
    while True:
        choice = menu_choice("TEAM MANAGEMENT", [
            ("Create Team",            None),
            ("List All Teams",         None),
            ("View Team by ID",        None),
            ("Join Team (via code)",    None),
            ("Remove Member",          None),
            ("Transfer Leadership",    None),
            ("← Back to Main Menu",    None),
        ])
        if   choice == 1: create_team()
        elif choice == 2: list_teams()
        elif choice == 3: view_team()
        elif choice == 4: join_team()
        elif choice == 5: remove_member()
        elif choice == 6: transfer_leadership()
        elif choice == 7: return


def create_team():
    print(f"\n  {C.BOLD}{C.MAGENTA}── Create Team ──{C.RESET}")
    body = {
        "teamName":    prompt("Team Name"),
        "leaderId":    prompt_optional("Leader Participant ID"),
        "hackathonId": prompt_optional("Hackathon ID"),
    }
    body = {k: v for k, v in body.items() if v is not None}
    ok, data = api("post", "/teams", body)
    if ok:
        success(f"Team created!  ID: {C.BOLD}{data['id']}{C.RESET}")
        info(f"Join Code: {C.BOLD}{C.YELLOW}{data.get('teamCode','—')}{C.RESET}")
        show_entity("Team", data, [
            ("id", "ID"), ("teamName", "Name"), ("teamCode", "Join Code"),
            ("leaderId", "Leader ID"), ("hackathonId", "Hackathon ID"),
            ("members", "Members"),
        ])
    else:
        error(data)
    pause()


def list_teams():
    ok, data = api("get", "/teams")
    if ok:
        rows = [(t.get("id",""), t.get("teamName",""), t.get("teamCode",""),
                 str(len(t.get("members",[]))), t.get("leaderId","—"))
                for t in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── All Teams ──{C.RESET}")
        print_table(["ID", "Name", "Join Code", "Members", "Leader ID"], rows)
    else:
        error(data)
    pause()


def view_team():
    tid = prompt("Team ID")
    ok, data = api("get", f"/teams/{tid}")
    if ok:
        show_entity("Team", data, [
            ("id", "ID"), ("teamName", "Name"), ("teamCode", "Join Code"),
            ("leaderId", "Leader ID"), ("hackathonId", "Hackathon ID"),
            ("members", "Members"),
        ])
    else:
        error(data)
    pause()


def join_team():
    code = prompt("Team Join Code")
    pid  = prompt("Your Participant ID")
    ok, data = api("post", f"/teams/{code}/join", {"participantId": pid})
    if ok:
        success(f"Joined team: {C.BOLD}{data.get('teamName','')}{C.RESET}")
        info(f"Members: {', '.join(data.get('members', []))}")
    else:
        error(data)
    pause()


def remove_member():
    tid = prompt("Team ID")
    pid = prompt("Participant ID to remove")
    ok, data = api("delete", f"/teams/{tid}/members/{pid}")
    if ok:
        success(f"Member removed from team.")
    else:
        error(data)
    pause()


def transfer_leadership():
    tid = prompt("Team ID")
    new_leader = prompt("New Leader Participant ID")
    ok, data = api("patch", f"/teams/{tid}/leader", {"newLeaderId": new_leader})
    if ok:
        success(f"Leadership transferred to: {C.BOLD}{new_leader}{C.RESET}")
    else:
        error(data)
    pause()


# ══════════════════════════════════════════════════════════════
#  JUDGE MANAGEMENT
# ══════════════════════════════════════════════════════════════
def judge_menu():
    while True:
        choice = menu_choice("JUDGE MANAGEMENT", [
            ("Register Judge",         None),
            ("List All Judges",        None),
            ("View Judge by ID",       None),
            ("Assign Judge to Track",  None),
            ("Unassign Judge",         None),
            ("← Back to Main Menu",    None),
        ])
        if   choice == 1: create_judge()
        elif choice == 2: list_judges()
        elif choice == 3: view_judge()
        elif choice == 4: assign_judge()
        elif choice == 5: unassign_judge()
        elif choice == 6: return


def create_judge():
    print(f"\n  {C.BOLD}{C.MAGENTA}── Register Judge ──{C.RESET}")
    body = {
        "name":      prompt("Name"),
        "email":     prompt("Email"),
        "expertise": prompt_optional("Expertise / Domain"),
    }
    body = {k: v for k, v in body.items() if v is not None}
    ok, data = api("post", "/judges", body)
    if ok:
        success(f"Judge registered!  ID: {C.BOLD}{data['id']}{C.RESET}")
        show_entity("Judge", data, [
            ("id", "ID"), ("name", "Name"), ("email", "Email"),
            ("expertise", "Expertise"), ("assignedTrack", "Assigned Track"),
        ])
    else:
        error(data)
    pause()


def list_judges():
    ok, data = api("get", "/judges")
    if ok:
        rows = [(j.get("id",""), j.get("name",""), j.get("email",""),
                 j.get("expertise","—"), j.get("assignedTrack","—"))
                for j in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── All Judges ──{C.RESET}")
        print_table(["ID", "Name", "Email", "Expertise", "Track"], rows)
    else:
        error(data)
    pause()


def view_judge():
    jid = prompt("Judge ID")
    ok, data = api("get", f"/judges/{jid}")
    if ok:
        show_entity("Judge", data, [
            ("id", "ID"), ("name", "Name"), ("email", "Email"),
            ("expertise", "Expertise"), ("assignedTrack", "Assigned Track"),
        ])
    else:
        error(data)
    pause()


def assign_judge():
    jid = prompt("Judge ID")
    tid = prompt("Track ID to assign")
    ok, data = api("post", f"/judges/{jid}/assign", {"trackId": tid})
    if ok:
        success(f"Judge assigned to track: {C.BOLD}{tid}{C.RESET}")
    else:
        error(data)
    pause()


def unassign_judge():
    jid = prompt("Judge ID")
    ok, data = api("delete", f"/judges/{jid}/assign")
    if ok:
        success("Judge unassigned from track.")
    else:
        error(data)
    pause()


# ══════════════════════════════════════════════════════════════
#  TRACK MANAGEMENT
# ══════════════════════════════════════════════════════════════
def track_menu():
    while True:
        choice = menu_choice("TRACK MANAGEMENT", [
            ("Add Track to Hackathon",       None),
            ("List All Tracks",              None),
            ("View Track by ID",             None),
            ("List Tracks by Hackathon",     None),
            ("Update Track",                 None),
            ("View Submissions in Track",    None),
            ("Delete Track",                 None),
            ("← Back to Main Menu",          None),
        ])
        if   choice == 1: create_track()
        elif choice == 2: list_tracks()
        elif choice == 3: view_track()
        elif choice == 4: tracks_by_hackathon()
        elif choice == 5: update_track()
        elif choice == 6: track_submissions()
        elif choice == 7: delete_track()
        elif choice == 8: return


def create_track():
    print(f"\n  {C.BOLD}{C.MAGENTA}── Add Track ──{C.RESET}")
    hid = prompt("Hackathon ID")
    body = {
        "name":        prompt("Track Name"),
        "description": prompt_optional("Description"),
    }
    body = {k: v for k, v in body.items() if v is not None}
    ok, data = api("post", f"/hackathons/{hid}/tracks", body)
    if ok:
        success(f"Track created!  ID: {C.BOLD}{data['id']}{C.RESET}")
        show_entity("Track", data, [
            ("id", "ID"), ("name", "Name"), ("description", "Description"),
            ("hackathonId", "Hackathon ID"),
        ])
    else:
        error(data)
    pause()


def list_tracks():
    ok, data = api("get", "/tracks")
    if ok:
        rows = [(t.get("id",""), t.get("name",""), t.get("description","—"),
                 t.get("hackathonId","—")) for t in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── All Tracks ──{C.RESET}")
        print_table(["ID", "Name", "Description", "Hackathon ID"], rows)
    else:
        error(data)
    pause()


def view_track():
    tid = prompt("Track ID")
    ok, data = api("get", f"/tracks/{tid}")
    if ok:
        show_entity("Track", data, [
            ("id", "ID"), ("name", "Name"), ("description", "Description"),
            ("hackathonId", "Hackathon ID"),
        ])
    else:
        error(data)
    pause()


def tracks_by_hackathon():
    hid = prompt("Hackathon ID")
    ok, data = api("get", f"/hackathons/{hid}/tracks")
    if ok:
        rows = [(t.get("id",""), t.get("name",""), t.get("description","—"))
                for t in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── Tracks for Hackathon {hid} ──{C.RESET}")
        print_table(["ID", "Name", "Description"], rows)
    else:
        error(data)
    pause()


def update_track():
    tid = prompt("Track ID to update")
    print(f"  {C.DIM}(Leave blank to skip a field){C.RESET}")
    body = {}
    v = prompt_optional("New Name")
    if v: body["name"] = v
    v = prompt_optional("New Description")
    if v: body["description"] = v
    if not body:
        warn("Nothing to update.")
        return
    ok, data = api("patch", f"/tracks/{tid}", body)
    if ok:
        success("Track updated!")
        show_entity("Track", data, [
            ("id", "ID"), ("name", "Name"), ("description", "Description"),
        ])
    else:
        error(data)
    pause()


def track_submissions():
    tid = prompt("Track ID")
    ok, data = api("get", f"/tracks/{tid}/submissions")
    if ok:
        rows = [(s.get("id",""), s.get("projectTitle",""), s.get("teamId",""),
                 s.get("repoLink","—")) for s in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── Submissions in Track {tid} ──{C.RESET}")
        print_table(["ID", "Project Title", "Team ID", "Repo Link"], rows)
    else:
        error(data)
    pause()


def delete_track():
    tid = prompt("Track ID to delete")
    confirm = input(f"  {C.RED}⚠ Are you sure? (yes/no): {C.RESET}").strip().lower()
    if confirm in ("yes", "y"):
        ok, data = api("delete", f"/tracks/{tid}")
        if ok:
            success("Track deleted.")
        else:
            error(data)
    else:
        info("Cancelled.")
    pause()


# ══════════════════════════════════════════════════════════════
#  SUBMISSION MANAGEMENT
# ══════════════════════════════════════════════════════════════
def submission_menu():
    while True:
        choice = menu_choice("SUBMISSION MANAGEMENT", [
            ("Create Submission",       None),
            ("List All Submissions",    None),
            ("View Submission by ID",   None),
            ("Update Submission",       None),
            ("Delete Submission",       None),
            ("← Back to Main Menu",     None),
        ])
        if   choice == 1: create_submission()
        elif choice == 2: list_submissions()
        elif choice == 3: view_submission()
        elif choice == 4: update_submission()
        elif choice == 5: delete_submission()
        elif choice == 6: return


def create_submission():
    print(f"\n  {C.BOLD}{C.MAGENTA}── Create Submission ──{C.RESET}")
    body = {
        "projectTitle": prompt("Project Title"),
        "trackId":      prompt("Track ID"),
        "teamId":       prompt("Team ID"),
        "repoLink":     prompt_optional("Repository Link"),
        "demoLink":     prompt_optional("Demo Link"),
        "description":  prompt_optional("Description"),
    }
    body = {k: v for k, v in body.items() if v is not None}
    ok, data = api("post", "/submissions", body)
    if ok:
        success(f"Submission created!  ID: {C.BOLD}{data['id']}{C.RESET}")
        show_entity("Submission", data, [
            ("id", "ID"), ("projectTitle", "Project Title"),
            ("trackId", "Track ID"), ("teamId", "Team ID"),
            ("repoLink", "Repo Link"), ("demoLink", "Demo Link"),
            ("description", "Description"),
        ])
    else:
        error(data)
    pause()


def list_submissions():
    ok, data = api("get", "/submissions")
    if ok:
        rows = [(s.get("id",""), s.get("projectTitle",""), s.get("teamId",""),
                 s.get("trackId",""), s.get("repoLink","—"))
                for s in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── All Submissions ──{C.RESET}")
        print_table(["ID", "Project Title", "Team ID", "Track ID", "Repo Link"], rows)
    else:
        error(data)
    pause()


def view_submission():
    sid = prompt("Submission ID")
    ok, data = api("get", f"/submissions/{sid}")
    if ok:
        show_entity("Submission", data, [
            ("id", "ID"), ("projectTitle", "Project Title"),
            ("trackId", "Track ID"), ("teamId", "Team ID"),
            ("repoLink", "Repo Link"), ("demoLink", "Demo Link"),
            ("description", "Description"),
        ])
    else:
        error(data)
    pause()


def update_submission():
    sid = prompt("Submission ID to update")
    print(f"  {C.DIM}(Leave blank to skip a field){C.RESET}")
    body = {}
    v = prompt_optional("New Project Title")
    if v: body["projectTitle"] = v
    v = prompt_optional("New Repo Link")
    if v: body["repoLink"] = v
    v = prompt_optional("New Demo Link")
    if v: body["demoLink"] = v
    v = prompt_optional("New Description")
    if v: body["description"] = v
    if not body:
        warn("Nothing to update.")
        return
    ok, data = api("patch", f"/submissions/{sid}", body)
    if ok:
        success("Submission updated!")
        show_entity("Submission", data, [
            ("id", "ID"), ("projectTitle", "Project Title"),
            ("repoLink", "Repo Link"), ("demoLink", "Demo Link"),
        ])
    else:
        error(data)
    pause()


def delete_submission():
    sid = prompt("Submission ID to delete")
    confirm = input(f"  {C.RED}⚠ Are you sure? (yes/no): {C.RESET}").strip().lower()
    if confirm in ("yes", "y"):
        ok, data = api("delete", f"/submissions/{sid}")
        if ok:
            success("Submission withdrawn.")
        else:
            error(data)
    else:
        info("Cancelled.")
    pause()


# ══════════════════════════════════════════════════════════════
#  SCORE & LEADERBOARD MANAGEMENT
# ══════════════════════════════════════════════════════════════
def score_menu():
    while True:
        choice = menu_choice("SCORES & LEADERBOARD", [
            ("Submit Score",                     None),
            ("List All Scores",                  None),
            ("View Score by ID",                 None),
            ("Update / Revise Score",            None),
            ("View Scores for a Submission",     None),
            ("⭐ Leaderboard (by Submission)",   None),
            ("← Back to Main Menu",              None),
        ])
        if   choice == 1: submit_score()
        elif choice == 2: list_scores()
        elif choice == 3: view_score()
        elif choice == 4: update_score()
        elif choice == 5: scores_by_submission()
        elif choice == 6: leaderboard()
        elif choice == 7: return


def submit_score():
    print(f"\n  {C.BOLD}{C.MAGENTA}── Submit Score ──{C.RESET}")
    body = {
        "judgeId":      prompt("Judge ID"),
        "submissionId": prompt("Submission ID"),
        "innovation":   prompt_int("Innovation (0-10)", lo=0, hi=10),
        "execution":    prompt_int("Execution  (0-10)", lo=0, hi=10),
        "presentation": prompt_int("Presentation (0-10)", lo=0, hi=10),
    }
    ok, data = api("post", "/scores", body)
    if ok:
        success(f"Score submitted!  Total: {C.BOLD}{data.get('total', '—')}/30{C.RESET}")
        show_entity("Score", data, [
            ("id", "ID"), ("judgeId", "Judge ID"), ("submissionId", "Submission ID"),
            ("innovation", "Innovation"), ("execution", "Execution"),
            ("presentation", "Presentation"), ("total", "Total"),
        ])
    else:
        error(data)
    pause()


def list_scores():
    ok, data = api("get", "/scores")
    if ok:
        rows = [(s.get("id",""), s.get("submissionId",""), s.get("judgeId",""),
                 str(s.get("innovation","")), str(s.get("execution","")),
                 str(s.get("presentation","")), str(s.get("total","")))
                for s in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── All Scores ──{C.RESET}")
        print_table(["ID", "Submission", "Judge", "Innov.", "Exec.", "Pres.", "Total"], rows)
    else:
        error(data)
    pause()


def view_score():
    sid = prompt("Score ID")
    ok, data = api("get", f"/scores/{sid}")
    if ok:
        show_entity("Score", data, [
            ("id", "ID"), ("judgeId", "Judge ID"), ("submissionId", "Submission ID"),
            ("innovation", "Innovation"), ("execution", "Execution"),
            ("presentation", "Presentation"), ("total", "Total"),
        ])
    else:
        error(data)
    pause()


def update_score():
    sid = prompt("Score ID to revise")
    print(f"\n  {C.DIM}Enter new scores (all three are required){C.RESET}")
    body = {
        "innovation":   prompt_int("Innovation (0-10)", lo=0, hi=10),
        "execution":    prompt_int("Execution  (0-10)", lo=0, hi=10),
        "presentation": prompt_int("Presentation (0-10)", lo=0, hi=10),
    }
    ok, data = api("patch", f"/scores/{sid}", body)
    if ok:
        success(f"Score revised!  New Total: {C.BOLD}{data.get('total', '—')}/30{C.RESET}")
    else:
        error(data)
    pause()


def scores_by_submission():
    sid = prompt("Submission ID")
    ok, data = api("get", f"/scores/submission/{sid}")
    if ok:
        rows = [(s.get("id",""), s.get("judgeId",""),
                 str(s.get("innovation","")), str(s.get("execution","")),
                 str(s.get("presentation","")), str(s.get("total","")))
                for s in data]
        print(f"\n  {C.BOLD}{C.MAGENTA}── Scores for Submission {sid} ──{C.RESET}")
        print_table(["Score ID", "Judge ID", "Innov.", "Exec.", "Pres.", "Total"], rows)
        if data:
            avg = sum(s.get("total", 0) for s in data) / len(data)
            print(f"\n  {C.BOLD}{C.GREEN}Average Score: {avg:.1f}/30{C.RESET}")
    else:
        error(data)
    pause()


def leaderboard():
    """Build a leaderboard by aggregating scores across all submissions."""
    print(f"\n  {C.BOLD}{C.YELLOW}⭐ Building Leaderboard...{C.RESET}")
    ok_scores, scores = api("get", "/scores")
    ok_subs, subs = api("get", "/submissions")
    if not ok_scores or not ok_subs:
        error("Could not fetch data for leaderboard.")
        pause()
        return

    # Aggregate: submissionId -> { total, count, title, teamId }
    sub_map = {s["id"]: s for s in subs}
    board = {}
    for sc in scores:
        sid = sc.get("submissionId", "")
        if sid not in board:
            sub_info = sub_map.get(sid, {})
            board[sid] = {
                "title": sub_info.get("projectTitle", "Unknown"),
                "teamId": sub_info.get("teamId", "—"),
                "total": 0,
                "count": 0,
            }
        board[sid]["total"] += sc.get("total", 0)
        board[sid]["count"] += 1

    ranked = sorted(board.items(), key=lambda x: x[1]["total"], reverse=True)
    rows = []
    for rank, (sid, info) in enumerate(ranked, 1):
        medal = "🥇" if rank == 1 else "🥈" if rank == 2 else "🥉" if rank == 3 else f"#{rank}"
        avg = info["total"] / info["count"] if info["count"] else 0
        rows.append((medal, info["title"], info["teamId"],
                      str(info["total"]), f"{avg:.1f}", str(info["count"])))

    print(f"\n  {C.BOLD}{C.YELLOW}{'═' * 58}{C.RESET}")
    print(f"  {C.BOLD}{C.YELLOW}  ⭐  HACKATHON LEADERBOARD  ⭐{C.RESET}")
    print(f"  {C.BOLD}{C.YELLOW}{'═' * 58}{C.RESET}")
    print_table(["Rank", "Project", "Team ID", "Total", "Avg", "Judges"], rows)
    pause()


# ══════════════════════════════════════════════════════════════
#  QUICK STATUS DASHBOARD
# ══════════════════════════════════════════════════════════════
def dashboard():
    """Show a quick overview of all entity counts."""
    print(f"\n  {C.BOLD}{C.CYAN}📊  PLATFORM DASHBOARD{C.RESET}")
    hr("═")
    entities = [
        ("Hackathons",    "/hackathons"),
        ("Participants",  "/participants"),
        ("Teams",         "/teams"),
        ("Judges",        "/judges"),
        ("Tracks",        "/tracks"),
        ("Submissions",   "/submissions"),
        ("Scores",        "/scores"),
    ]
    for name, path in entities:
        ok, data = api("get", path)
        count = len(data) if ok and isinstance(data, list) else "?"
        bar = "█" * min(count if isinstance(count, int) else 0, 30)
        print(f"  {C.BOLD}{name:15s}{C.RESET} {C.GREEN}{bar}{C.RESET} {C.BOLD}{count}{C.RESET}")
    hr("═")
    pause()


# ══════════════════════════════════════════════════════════════
#  MAIN MENU
# ══════════════════════════════════════════════════════════════
def main_menu():
    while True:
        banner()
        choice = menu_choice("MAIN MENU", [
            ("📊  Dashboard (Quick Overview)",  None),
            ("🏆  Hackathons",                  None),
            ("👥  Participants",                None),
            ("🤝  Teams",                       None),
            ("⚖️   Judges",                     None),
            ("🛤️   Tracks",                     None),
            ("📦  Submissions",                 None),
            ("⭐  Scores & Leaderboard",        None),
            ("🚪  Exit",                        None),
        ])
        if   choice == 1: dashboard()
        elif choice == 2: hackathon_menu()
        elif choice == 3: participant_menu()
        elif choice == 4: team_menu()
        elif choice == 5: judge_menu()
        elif choice == 6: track_menu()
        elif choice == 7: submission_menu()
        elif choice == 8: score_menu()
        elif choice == 9:
            print(f"\n  {C.BOLD}{C.CYAN}👋  Goodbye! Happy Hacking!{C.RESET}\n")
            sys.exit(0)


# ──────────────────────────────────────────────────────────────
#  Entry point
# ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Hackathon Platform CLI")
    parser.add_argument("--base-url", default="http://localhost:8080",
                        help="Base URL of the Hackathon Platform API (default: http://localhost:8080)")
    args = parser.parse_args()
    BASE_URL = args.base_url

    try:
        main_menu()
    except KeyboardInterrupt:
        print(f"\n\n  {C.BOLD}{C.CYAN}👋  Interrupted. Goodbye!{C.RESET}\n")
        sys.exit(0)
