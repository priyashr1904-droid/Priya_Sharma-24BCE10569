package com.hackathon.platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackathonPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
