package com.hackathon.platform.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.*;

@Document(collection = "tracks")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Track {

    @Id
    private String id;

    @NotBlank(message = "Track name is required")
    private String name;

    private String description;

    private String hackathonId;
}
