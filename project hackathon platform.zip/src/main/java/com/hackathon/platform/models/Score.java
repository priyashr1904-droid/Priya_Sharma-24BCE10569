package com.hackathon.platform.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.*;

@Document(collection = "scores")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Score {

    @Id
    private String id;

    @NotBlank(message = "Judge ID is required")
    private String judgeId;

    @NotBlank(message = "Submission ID is required")
    private String submissionId;

    @Min(0) @Max(10)
    private int innovation;

    @Min(0) @Max(10)
    private int execution;

    @Min(0) @Max(10)
    private int presentation;

    private int total;
}
