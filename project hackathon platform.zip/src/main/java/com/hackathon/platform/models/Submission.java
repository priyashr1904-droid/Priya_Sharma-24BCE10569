package com.hackathon.platform.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.*;

@Document(collection = "submissions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Submission {

    @Id
    private String id;

    @NotBlank(message = "Project title is required")
    private String projectTitle;

    private String repoLink;

    private String demoLink;

    private String description;

    @NotBlank(message = "Track ID is required")
    private String trackId;

    @NotBlank(message = "Team ID is required")
    private String teamId;
}
