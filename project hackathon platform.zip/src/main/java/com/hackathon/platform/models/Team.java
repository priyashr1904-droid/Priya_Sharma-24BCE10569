package com.hackathon.platform.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.index.Indexed;
import jakarta.validation.constraints.*;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "teams")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Team {

    @Id
    private String id;

    @NotBlank(message = "Team name is required")
    private String teamName;

    @Indexed(unique = true)
    private String teamCode;

    @Builder.Default
    private List<String> members = new ArrayList<>();

    private String leaderId;

    private String hackathonId;
}
