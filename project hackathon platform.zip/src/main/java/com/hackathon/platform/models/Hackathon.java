package com.hackathon.platform.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Document(collection = "hackathons")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Hackathon {

    @Id
    private String id;

    @NotBlank(message = "Title is required")
    private String title;

    private String theme;

    private LocalDate startDate;

    private LocalDate endDate;

    @Builder.Default
    private String status = "Draft";

    private int maxTeamSize;
}
