package com.hackathon.platform.services;

import com.hackathon.platform.models.Team;
import com.hackathon.platform.repositories.TeamRepo;
import com.hackathon.platform.repositories.HackathonRepo;
import com.hackathon.platform.repositories.ParticipantRepo;
import com.hackathon.platform.exceptions.ResourceNotFoundException;
import com.hackathon.platform.exceptions.InvalidHackathonRequestException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TeamService {

    private final TeamRepo teamRepo;
    private final HackathonRepo hackathonRepo;
    private final ParticipantRepo participantRepo;

    public Team createTeam(Team draftTeam) {
        // Conversational comment: Ensure the target hackathon actually exists and registration is open
        if (draftTeam.getHackathonId() != null) {
            hackathonRepo.findById(draftTeam.getHackathonId())
                .map(h -> {
                    if (!"Registration".equalsIgnoreCase(h.getStatus()) && !"Draft".equalsIgnoreCase(h.getStatus())) {
                        throw new InvalidHackathonRequestException("Registration is closed. Hackathon status is: " + h.getStatus());
                    }
                    return h;
                })
                .orElseThrow(() -> new ResourceNotFoundException("Cannot form team. Hackathon ID '" + draftTeam.getHackathonId() + "' not found."));
        }

        // Generate a clean unique code for joining
        draftTeam.setTeamCode(UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        
        if (draftTeam.getLeaderId() != null) {
            if (!participantRepo.existsById(draftTeam.getLeaderId())) {
                throw new ResourceNotFoundException("Assigning team captain failed. Participant '" + draftTeam.getLeaderId() + "' not found.");
            }
            if (!draftTeam.getMembers().contains(draftTeam.getLeaderId())) {
                draftTeam.getMembers().add(draftTeam.getLeaderId());
            }
        }
        return teamRepo.save(draftTeam);
    }

    public List<Team> getAllTeams() {
        return teamRepo.findAll();
    }

    public Optional<Team> getTeamById(String teamId) {
        return teamRepo.findById(teamId);
    }

    public Team joinTeam(String teamCode, String prospectiveMemberId) {
        Team team = teamRepo.findByTeamCode(teamCode)
                .orElseThrow(() -> new ResourceNotFoundException("No team matches join code: " + teamCode));

        // Check if user is registered in the database
        if (!participantRepo.existsById(prospectiveMemberId)) {
            throw new ResourceNotFoundException("Cannot join team. Participant '" + prospectiveMemberId + "' not found.");
        }

        // Business Rule: Check if we are exceeding the max team size configured for the hackathon
        if (team.getHackathonId() != null) {
            hackathonRepo.findById(team.getHackathonId()).ifPresent(h -> {
                if (h.getMaxTeamSize() > 0 && team.getMembers().size() >= h.getMaxTeamSize()) {
                    throw new InvalidHackathonRequestException(
                        String.format("Failed to join. Team '%s' has reached the maximum size limit of %d in '%s'", 
                            team.getTeamName(), h.getMaxTeamSize(), h.getTitle())
                    );
                }
            });
        }

        if (!team.getMembers().contains(prospectiveMemberId)) {
            team.getMembers().add(prospectiveMemberId);
        }
        return teamRepo.save(team);
    }

    public Team removeMember(String teamId, String leavingMemberId) {
        Team team = teamRepo.findById(teamId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot modify team. Team not found with ID: " + teamId));
        
        // Don't error out if they're not in the list, just save a redundant write operation
        if (team.getMembers().contains(leavingMemberId)) {
            team.getMembers().remove(leavingMemberId);
            // If the team leader is leaving, we need to assign a new one or clear leadership
            if (leavingMemberId.equals(team.getLeaderId())) {
                String nextLeader = team.getMembers().isEmpty() ? null : team.getMembers().get(0);
                team.setLeaderId(nextLeader);
            }
        }
        return teamRepo.save(team);
    }

    public Team transferLeadership(String teamId, String incomingCaptainId) {
        Team team = teamRepo.findById(teamId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot transfer captaincy. Team not found with ID: " + teamId));
        
        // Conversational comment: Make sure the new leader is actually part of this team
        if (!team.getMembers().contains(incomingCaptainId)) {
            throw new InvalidHackathonRequestException("New captain must already be a member of the team!");
        }
        
        team.setLeaderId(incomingCaptainId);
        return teamRepo.save(team);
    }

    public void deleteTeam(String teamId) {
        if (!teamRepo.existsById(teamId)) {
            throw new ResourceNotFoundException("Cannot delete team. Team not found with ID: " + teamId);
        }
        teamRepo.deleteById(teamId);
    }

    public List<Team> getTeamsByHackathon(String hackathonId) {
        return teamRepo.findByHackathonId(hackathonId);
    }
}

