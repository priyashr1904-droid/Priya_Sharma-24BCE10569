package com.hackathon.platform.services;

import com.hackathon.platform.models.Submission;
import com.hackathon.platform.repositories.SubmissionRepo;
import com.hackathon.platform.exceptions.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SubmissionService {

    private final SubmissionRepo submissionRepo;

    public Submission createSubmission(Submission submission) {
        return submissionRepo.save(submission);
    }

    public List<Submission> getAllSubmissions() {
        return submissionRepo.findAll();
    }

    public Optional<Submission> getSubmissionById(String submissionId) {
        return submissionRepo.findById(submissionId);
    }

    public Submission updateSubmission(String id, Submission freshSubmission) {
        return submissionRepo.findById(id).map(s -> {
            if (freshSubmission.getProjectTitle() != null) s.setProjectTitle(freshSubmission.getProjectTitle());
            if (freshSubmission.getRepoLink() != null) s.setRepoLink(freshSubmission.getRepoLink());
            if (freshSubmission.getDemoLink() != null) s.setDemoLink(freshSubmission.getDemoLink());
            if (freshSubmission.getDescription() != null) s.setDescription(freshSubmission.getDescription());
            return submissionRepo.save(s);
        }).orElseThrow(() -> new ResourceNotFoundException("Cannot update. Submission target ID '" + id + "' not found."));
    }

    public void deleteSubmission(String id) {
        if (!submissionRepo.existsById(id)) {
            throw new ResourceNotFoundException("Cannot delete submission. Entry not found with ID: " + id);
        }
        submissionRepo.deleteById(id);
    }

    public List<Submission> getSubmissionsByTrack(String trackId) {
        return submissionRepo.findByTrackId(trackId);
    }

    public List<Submission> getSubmissionsByTeam(String teamId) {
        return submissionRepo.findByTeamId(teamId);
    }
}

