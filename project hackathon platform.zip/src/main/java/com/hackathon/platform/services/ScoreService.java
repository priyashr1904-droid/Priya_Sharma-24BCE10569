package com.hackathon.platform.services;

import com.hackathon.platform.models.Score;
import com.hackathon.platform.models.Submission;
import com.hackathon.platform.models.Judge;
import com.hackathon.platform.repositories.ScoreRepo;
import com.hackathon.platform.repositories.SubmissionRepo;
import com.hackathon.platform.repositories.JudgeRepo;
import com.hackathon.platform.exceptions.ResourceNotFoundException;
import com.hackathon.platform.exceptions.InvalidHackathonRequestException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ScoreService {

    private final ScoreRepo scoreRepo;
    private final SubmissionRepo submissionRepo;
    private final JudgeRepo judgeRepo;

    public Score submitScore(Score rawScore) {
        // Human logic validation: ensure the judge and submission exist in DB
        Submission submission = submissionRepo.findById(rawScore.getSubmissionId())
                .orElseThrow(() -> new ResourceNotFoundException("Submission target ID '" + rawScore.getSubmissionId() + "' not found."));

        Judge judge = judgeRepo.findById(rawScore.getJudgeId())
                .orElseThrow(() -> new ResourceNotFoundException("Judge ID '" + rawScore.getJudgeId() + "' not registered."));

        // Human logic validation: ensure the judge is assigned to evaluate the track of this submission
        if (judge.getAssignedTrack() == null || !judge.getAssignedTrack().equalsIgnoreCase(submission.getTrackId())) {
            throw new InvalidHackathonRequestException(
                String.format("Permission Denied: Judge '%s' is assigned to track '%s', but this submission is under track '%s'.",
                    judge.getName(), judge.getAssignedTrack(), submission.getTrackId())
            );
        }

        // Auto-calculate the total points sum
        rawScore.setTotal(rawScore.getInnovation() + rawScore.getExecution() + rawScore.getPresentation());
        return scoreRepo.save(rawScore);
    }

    public List<Score> getAllScores() {
        return scoreRepo.findAll();
    }

    public Optional<Score> getScoreById(String scoreId) {
        return scoreRepo.findById(scoreId);
    }

    public Score updateScore(String scoreId, Score revisedScore) {
        return scoreRepo.findById(scoreId).map(s -> {
            s.setInnovation(revisedScore.getInnovation());
            s.setExecution(revisedScore.getExecution());
            s.setPresentation(revisedScore.getPresentation());
            s.setTotal(revisedScore.getInnovation() + revisedScore.getExecution() + revisedScore.getPresentation());
            return scoreRepo.save(s);
        }).orElseThrow(() -> new ResourceNotFoundException("Failed to update score. No score record found with ID: " + scoreId));
    }

    public List<Score> getScoresBySubmission(String submissionId) {
        return scoreRepo.findBySubmissionId(submissionId);
    }

    public List<Score> getScoresByJudge(String judgeId) {
        return scoreRepo.findByJudgeId(judgeId);
    }
}

