package com.hackathon.platform.services;

import com.hackathon.platform.models.Participant;
import com.hackathon.platform.repositories.ParticipantRepo;
import com.hackathon.platform.exceptions.ResourceNotFoundException;
import com.hackathon.platform.exceptions.InvalidHackathonRequestException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ParticipantService {

    private final ParticipantRepo participantRepo;

    public Participant registerParticipant(Participant freshCandidate) {
        // Real developers check for duplicate emails before database save to avoid MongoDB driver errors bubbling up raw.
        if (participantRepo.findByEmail(freshCandidate.getEmail()).isPresent()) {
            throw new InvalidHackathonRequestException(
                "A contestant with email '" + freshCandidate.getEmail() + "' is already registered on this platform."
            );
        }

        freshCandidate.setRegistrationDate(LocalDate.now());
        return participantRepo.save(freshCandidate);
    }

    public List<Participant> getAllParticipants() {
        return participantRepo.findAll();
    }

    public Optional<Participant> getParticipantById(String participantId) {
        return participantRepo.findById(participantId);
    }

    public Participant updateParticipant(String id, Participant revisedProfile) {
        return participantRepo.findById(id).map(p -> {
            // Check fields selectively so we don't wipe out existing profile details
            if (revisedProfile.getName() != null) p.setName(revisedProfile.getName());
            if (revisedProfile.getSkills() != null) p.setSkills(revisedProfile.getSkills());
            if (revisedProfile.getGithubProfile() != null) p.setGithubProfile(revisedProfile.getGithubProfile());
            return participantRepo.save(p);
        }).orElseThrow(() -> new ResourceNotFoundException("No active profile exists for participant ID: " + id));
    }

    public void deleteParticipant(String participantId) {
        // Conversational note: we should check if they exist before trying to delete, so we can return a proper 404
        if (!participantRepo.existsById(participantId)) {
            throw new ResourceNotFoundException("Could not delete. Participant not found with ID: " + participantId);
        }
        participantRepo.deleteById(participantId);
    }
}

