package com.hackathon.platform.services;

import com.hackathon.platform.models.Hackathon;
import com.hackathon.platform.repositories.HackathonRepo;
import com.hackathon.platform.exceptions.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class HackathonService {

    private final HackathonRepo hackathonRepo;

    public Hackathon createHackathon(Hackathon hackathon) {
        if (hackathon.getStatus() == null || hackathon.getStatus().isEmpty()) {
            hackathon.setStatus("Draft");
        }
        return hackathonRepo.save(hackathon);
    }

    public List<Hackathon> getAllHackathons() {
        return hackathonRepo.findAll();
    }

    public Optional<Hackathon> getHackathonById(String hackathonId) {
        return hackathonRepo.findById(hackathonId);
    }

    public Hackathon updateHackathon(String id, Hackathon modifiedHackathon) {
        return hackathonRepo.findById(id).map(h -> {
            if (modifiedHackathon.getTitle() != null) h.setTitle(modifiedHackathon.getTitle());
            if (modifiedHackathon.getTheme() != null) h.setTheme(modifiedHackathon.getTheme());
            if (modifiedHackathon.getStartDate() != null) h.setStartDate(modifiedHackathon.getStartDate());
            if (modifiedHackathon.getEndDate() != null) h.setEndDate(modifiedHackathon.getEndDate());
            if (modifiedHackathon.getMaxTeamSize() > 0) h.setMaxTeamSize(modifiedHackathon.getMaxTeamSize());
            return hackathonRepo.save(h);
        }).orElseThrow(() -> new ResourceNotFoundException("Cannot update. Hackathon target ID '" + id + "' not found."));
    }

    public Hackathon updateStatus(String id, String status) {
        return hackathonRepo.findById(id).map(h -> {
            h.setStatus(status);
            return hackathonRepo.save(h);
        }).orElseThrow(() -> new ResourceNotFoundException("Cannot adjust status. Hackathon target ID '" + id + "' not found."));
    }

    public void deleteHackathon(String id) {
        if (!hackathonRepo.existsById(id)) {
            throw new ResourceNotFoundException("Cannot delete hackathon. Entry not found with ID: " + id);
        }
        hackathonRepo.deleteById(id);
    }
}

