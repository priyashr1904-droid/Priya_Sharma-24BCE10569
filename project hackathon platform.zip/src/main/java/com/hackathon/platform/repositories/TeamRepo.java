package com.hackathon.platform.repositories;

import com.hackathon.platform.models.Team;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;

@Repository
public interface TeamRepo extends MongoRepository<Team, String> {
    Optional<Team> findByTeamCode(String teamCode);
    List<Team> findByHackathonId(String hackathonId);
}
