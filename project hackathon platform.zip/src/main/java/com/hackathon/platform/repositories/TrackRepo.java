package com.hackathon.platform.repositories;

import com.hackathon.platform.models.Track;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TrackRepo extends MongoRepository<Track, String> {
    List<Track> findByHackathonId(String hackathonId);
}
