package com.hackathon.platform.repositories;

import com.hackathon.platform.models.Hackathon;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HackathonRepo extends MongoRepository<Hackathon, String> {
}
