package com.hackathon.platform.repositories;

import com.hackathon.platform.models.Score;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ScoreRepo extends MongoRepository<Score, String> {
    List<Score> findBySubmissionId(String submissionId);
    List<Score> findByJudgeId(String judgeId);
}
