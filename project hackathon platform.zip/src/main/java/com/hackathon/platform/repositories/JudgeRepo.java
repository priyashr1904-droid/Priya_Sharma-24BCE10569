package com.hackathon.platform.repositories;

import com.hackathon.platform.models.Judge;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface JudgeRepo extends MongoRepository<Judge, String> {
    List<Judge> findByAssignedTrack(String trackId);
}
