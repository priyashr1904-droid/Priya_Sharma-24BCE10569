package com.hackathon.platform.repositories;

import com.hackathon.platform.models.Participant;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ParticipantRepo extends MongoRepository<Participant, String> {
    Optional<Participant> findByEmail(String email);
}
