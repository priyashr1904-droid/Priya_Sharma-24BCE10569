package com.hackathon.platform.repositories;

import com.hackathon.platform.models.Submission;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SubmissionRepo extends MongoRepository<Submission, String> {
    List<Submission> findByTrackId(String trackId);
    List<Submission> findByTeamId(String teamId);
}
