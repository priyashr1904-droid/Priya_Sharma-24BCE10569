package com.hackathon.platform.controllers;

import com.hackathon.platform.models.Score;
import com.hackathon.platform.services.ScoreService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/scores")
@RequiredArgsConstructor
@Tag(name = "Scores & Leaderboard", description = "Score submission and leaderboard APIs")
public class ScoreController {

    private final ScoreService scoreService;

    @PostMapping
    @Operation(summary = "Judge submits score for a submission (innovation + execution + presentation)")
    public ResponseEntity<Score> submitScore(@Valid @RequestBody Score score) {
        return new ResponseEntity<>(scoreService.submitScore(score), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all scores")
    public ResponseEntity<List<Score>> getAllScores() {
        return ResponseEntity.ok(scoreService.getAllScores());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get score by ID")
    public ResponseEntity<Score> getScoreById(@PathVariable String id) {
        return scoreService.getScoreById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Revise a score before closing")
    public ResponseEntity<Score> updateScore(@PathVariable String id, @RequestBody Score score) {
        return ResponseEntity.ok(scoreService.updateScore(id, score));
    }

    @GetMapping("/submission/{submissionId}")
    @Operation(summary = "All judge scores for one submission")
    public ResponseEntity<List<Score>> getScoresBySubmission(@PathVariable String submissionId) {
        return ResponseEntity.ok(scoreService.getScoresBySubmission(submissionId));
    }
}
