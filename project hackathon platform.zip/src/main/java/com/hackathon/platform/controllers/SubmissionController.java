package com.hackathon.platform.controllers;

import com.hackathon.platform.models.Submission;
import com.hackathon.platform.services.SubmissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/submissions")
@RequiredArgsConstructor
@Tag(name = "Submissions", description = "Project submission APIs")
public class SubmissionController {

    private final SubmissionService submissionService;

    @PostMapping
    @Operation(summary = "Team submits a project under a track")
    public ResponseEntity<Submission> createSubmission(@Valid @RequestBody Submission submission) {
        return new ResponseEntity<>(submissionService.createSubmission(submission), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all submissions")
    public ResponseEntity<List<Submission>> getAllSubmissions() {
        return ResponseEntity.ok(submissionService.getAllSubmissions());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Full submission detail with scores")
    public ResponseEntity<Submission> getSubmissionById(@PathVariable String id) {
        return submissionService.getSubmissionById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Update repo/demo link before deadline")
    public ResponseEntity<Submission> updateSubmission(@PathVariable String id, @RequestBody Submission submission) {
        return ResponseEntity.ok(submissionService.updateSubmission(id, submission));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Withdraw a submission")
    public ResponseEntity<Void> deleteSubmission(@PathVariable String id) {
        submissionService.deleteSubmission(id);
        return ResponseEntity.noContent().build();
    }
}
