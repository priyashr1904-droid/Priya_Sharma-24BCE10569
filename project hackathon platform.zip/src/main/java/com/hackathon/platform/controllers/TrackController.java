package com.hackathon.platform.controllers;

import com.hackathon.platform.models.Track;
import com.hackathon.platform.models.Submission;
import com.hackathon.platform.repositories.TrackRepo;
import com.hackathon.platform.services.SubmissionService;
import com.hackathon.platform.exceptions.ResourceNotFoundException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequiredArgsConstructor
@Tag(name = "Tracks", description = "Track management APIs")
public class TrackController {

    // Injecting the repository directly here since Track CRUD operations are pure database mappings.
    // Avoids bloating the codebase with a redundant service layer.
    private final TrackRepo trackRepo;
    private final SubmissionService submissionService;

    @PostMapping("/hackathons/{hackathonId}/tracks")
    @Operation(summary = "Add a new track to a hackathon")
    public ResponseEntity<Track> createTrack(@PathVariable String hackathonId, @Valid @RequestBody Track track) {
        track.setHackathonId(hackathonId);
        return new ResponseEntity<>(trackRepo.save(track), HttpStatus.CREATED);
    }

    @GetMapping("/tracks")
    @Operation(summary = "Get all tracks")
    public ResponseEntity<List<Track>> getAllTracks() {
        return ResponseEntity.ok(trackRepo.findAll());
    }

    @GetMapping("/tracks/{id}")
    @Operation(summary = "Get track by ID")
    public ResponseEntity<Track> getTrackById(@PathVariable String id) {
        Track trackObj = trackRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Track with ID '" + id + "' could not be found."));
        return ResponseEntity.ok(trackObj);
    }

    @PatchMapping("/tracks/{id}")
    @Operation(summary = "Update track description")
    public ResponseEntity<Track> updateTrack(@PathVariable String id, @RequestBody Track modifiedTrackDetails) {
        Track updated = trackRepo.findById(id).map(t -> {
            if (modifiedTrackDetails.getName() != null) t.setName(modifiedTrackDetails.getName());
            if (modifiedTrackDetails.getDescription() != null) t.setDescription(modifiedTrackDetails.getDescription());
            return trackRepo.save(t);
        }).orElseThrow(() -> new ResourceNotFoundException("Cannot update. No track matches ID: " + id));
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/tracks/{id}")
    @Operation(summary = "Remove a track")
    public ResponseEntity<Void> deleteTrack(@PathVariable String id) {
        if (!trackRepo.existsById(id)) {
            throw new ResourceNotFoundException("Cannot delete. Track with ID '" + id + "' does not exist.");
        }
        trackRepo.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/tracks/{id}/submissions")
    @Operation(summary = "All submissions under a track")
    public ResponseEntity<List<Submission>> getSubmissionsByTrack(@PathVariable String id) {
        return ResponseEntity.ok(submissionService.getSubmissionsByTrack(id));
    }

    @GetMapping("/hackathons/{hackathonId}/tracks")
    @Operation(summary = "Get all tracks for a hackathon")
    public ResponseEntity<List<Track>> getTracksByHackathon(@PathVariable String hackathonId) {
        return ResponseEntity.ok(trackRepo.findByHackathonId(hackathonId));
    }
}

