package com.hackathon.platform.controllers;

import com.hackathon.platform.models.Judge;
import com.hackathon.platform.repositories.JudgeRepo;
import com.hackathon.platform.exceptions.ResourceNotFoundException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/judges")
@RequiredArgsConstructor
@Tag(name = "Judges", description = "Judge management and track assignment APIs")
public class JudgeController {

    // Repository injected directly here to bypass a redundant service layer.
    private final JudgeRepo judgeRepo;

    @PostMapping
    @Operation(summary = "Register a judge")
    public ResponseEntity<Judge> registerJudge(@Valid @RequestBody Judge judge) {
        return new ResponseEntity<>(judgeRepo.save(judge), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all judges")
    public ResponseEntity<List<Judge>> getAllJudges() {
        return ResponseEntity.ok(judgeRepo.findAll());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get judge by ID")
    public ResponseEntity<Judge> getJudgeById(@PathVariable String id) {
        Judge judge = judgeRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No evaluator registered under ID: " + id));
        return ResponseEntity.ok(judge);
    }

    @PostMapping("/{id}/assign")
    @Operation(summary = "Assign judge to a specific track")
    public ResponseEntity<Judge> assignTrack(@PathVariable String id, @RequestBody Map<String, String> body) {
        String targetTrackId = body.get("trackId");
        
        // Conversational comment to explain why this check is inline
        // Make sure the judge actually exists in our DB before trying to bind them to a track!
        Judge judge = judgeRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot assign track. Judge ID '" + id + "' not found."));
        
        judge.setAssignedTrack(targetTrackId);
        return ResponseEntity.ok(judgeRepo.save(judge));
    }

    @DeleteMapping("/{id}/assign")
    @Operation(summary = "Unassign judge from track")
    public ResponseEntity<Judge> unassignTrack(@PathVariable String id) {
        Judge judge = judgeRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot unassign track. Judge ID '" + id + "' not found."));
        
        judge.setAssignedTrack(null);
        return ResponseEntity.ok(judgeRepo.save(judge));
    }
}

