package com.hackathon.platform.controllers;

import com.hackathon.platform.models.Participant;
import com.hackathon.platform.services.ParticipantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/participants")
@RequiredArgsConstructor
@Tag(name = "Participants", description = "Participant registration and management APIs")
public class ParticipantController {

    private final ParticipantService participantService;

    @PostMapping
    @Operation(summary = "Register a new participant")
    public ResponseEntity<Participant> registerParticipant(@Valid @RequestBody Participant participant) {
        return new ResponseEntity<>(participantService.registerParticipant(participant), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all participants")
    public ResponseEntity<List<Participant>> getAllParticipants() {
        return ResponseEntity.ok(participantService.getAllParticipants());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get participant by ID")
    public ResponseEntity<Participant> getParticipantById(@PathVariable String id) {
        return participantService.getParticipantById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Update participant profile (skills, github etc.)")
    public ResponseEntity<Participant> updateParticipant(@PathVariable String id, @RequestBody Participant participant) {
        return ResponseEntity.ok(participantService.updateParticipant(id, participant));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Remove participant")
    public ResponseEntity<Void> deleteParticipant(@PathVariable String id) {
        participantService.deleteParticipant(id);
        return ResponseEntity.noContent().build();
    }
}
