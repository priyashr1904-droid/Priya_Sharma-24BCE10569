package com.hackathon.platform.controllers;

import com.hackathon.platform.models.Team;
import com.hackathon.platform.services.TeamService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/teams")
@RequiredArgsConstructor
@Tag(name = "Teams", description = "Team creation and member management APIs")
public class TeamController {

    private final TeamService teamService;

    @PostMapping
    @Operation(summary = "Create a team, auto-generate join code")
    public ResponseEntity<Team> createTeam(@Valid @RequestBody Team team) {
        return new ResponseEntity<>(teamService.createTeam(team), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all teams")
    public ResponseEntity<List<Team>> getAllTeams() {
        return ResponseEntity.ok(teamService.getAllTeams());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Team profile with all members + submission")
    public ResponseEntity<Team> getTeamById(@PathVariable String id) {
        return teamService.getTeamById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{code}/join")
    @Operation(summary = "Participant joins via team code")
    public ResponseEntity<Team> joinTeam(@PathVariable String code, @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(teamService.joinTeam(code, body.get("participantId")));
    }

    @DeleteMapping("/{id}/members/{participantId}")
    @Operation(summary = "Kick a member from the team")
    public ResponseEntity<Team> removeMember(@PathVariable String id, @PathVariable String participantId) {
        return ResponseEntity.ok(teamService.removeMember(id, participantId));
    }

    @PatchMapping("/{id}/leader")
    @Operation(summary = "Transfer team leadership")
    public ResponseEntity<Team> transferLeadership(@PathVariable String id, @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(teamService.transferLeadership(id, body.get("newLeaderId")));
    }
}
