package com.hackathon.platform.controllers;

import com.hackathon.platform.models.Hackathon;
import com.hackathon.platform.services.HackathonService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/hackathons")
@RequiredArgsConstructor
@Tag(name = "Hackathons", description = "Hackathon management APIs")
public class HackathonController {

    private final HackathonService hackathonService;

    @PostMapping
    @Operation(summary = "Create a new hackathon with theme + timeline")
    public ResponseEntity<Hackathon> createHackathon(@Valid @RequestBody Hackathon hackathon) {
        return new ResponseEntity<>(hackathonService.createHackathon(hackathon), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all hackathons")
    public ResponseEntity<List<Hackathon>> getAllHackathons() {
        return ResponseEntity.ok(hackathonService.getAllHackathons());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get hackathon by ID")
    public ResponseEntity<Hackathon> getHackathonById(@PathVariable String id) {
        return hackathonService.getHackathonById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Update hackathon details or extend deadline")
    public ResponseEntity<Hackathon> updateHackathon(@PathVariable String id, @RequestBody Hackathon hackathon) {
        return ResponseEntity.ok(hackathonService.updateHackathon(id, hackathon));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Update hackathon lifecycle status (Draft → Registration → Active → Judging → Closed)")
    public ResponseEntity<Hackathon> updateStatus(@PathVariable String id, @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(hackathonService.updateStatus(id, body.get("status")));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Cancel/drop a hackathon")
    public ResponseEntity<Void> deleteHackathon(@PathVariable String id) {
        hackathonService.deleteHackathon(id);
        return ResponseEntity.noContent().build();
    }
}
