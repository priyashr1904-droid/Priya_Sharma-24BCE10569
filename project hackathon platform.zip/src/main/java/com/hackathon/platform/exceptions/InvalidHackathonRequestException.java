package com.hackathon.platform.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InvalidHackathonRequestException extends RuntimeException {
    public InvalidHackathonRequestException(String message) {
        super(message);
    }
}
