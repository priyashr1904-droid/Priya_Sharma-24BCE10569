package com.hackathon.platform.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;

@RestControllerAdvice
public class GlobalErrorHandler {

    // Simple record to hold error details. Using a record because it's clean and modern.
    public record ErrorDetails(
        String details,
        int statusCode,
        long epochMs
    ) {}

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorDetails> handleNotFound(ResourceNotFoundException ex) {
        ErrorDetails details = new ErrorDetails(ex.getMessage(), HttpStatus.NOT_FOUND.value(), Instant.now().toEpochMilli());
        return new ResponseEntity<>(details, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(InvalidHackathonRequestException.class)
    public ResponseEntity<ErrorDetails> handleBadRequest(InvalidHackathonRequestException ex) {
        ErrorDetails details = new ErrorDetails(ex.getMessage(), HttpStatus.BAD_REQUEST.value(), Instant.now().toEpochMilli());
        return new ResponseEntity<>(details, HttpStatus.BAD_REQUEST);
    }

    // A fallback to ensure we don't dump stack traces to the API client when things explode unexpectedly
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorDetails> handleGeneralException(Exception ex) {
        ErrorDetails details = new ErrorDetails(
            "An unexpected platform error occurred: " + ex.getMessage(), 
            HttpStatus.INTERNAL_SERVER_ERROR.value(), 
            Instant.now().toEpochMilli()
        );
        return new ResponseEntity<>(details, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
